---
license: other
language:
- en
task_categories:
- text-generation
tags:
- diplomacy
- multi-agent
- negotiation
- strategic-reasoning
- synthetic-data
configs:
- config_name: default
  data_files:
  - split: train
    path: data/train/*.jsonl.gz
---

# AI Diplomacy persuasion corpus v3

Private research dataset of three model-driven vanilla Diplomacy opening games. Each row preserves the July v2 core trace shape, with two explicit gameplay extensions for synthetic private in-game press messages and public board snapshots. Rows include the game-engine adjudicated orders and outcomes.

The three games use distinct seeds. All 105 Codex calls succeeded. The package contains three JSONL rows in gzip format. `release_manifest.json` records per-run calls, game content counts, usage totals, and row hashes.

All in-game press and decisions are synthetic. This release excludes model prompt/response envelopes, internal diaries, summaries, agent-state dumps, credentials, and host/runtime artifacts. The v2 release remains unchanged.

---
license: other
language:
- en
task_categories:
- text-generation
tags:
- multi-agent
- strategic-reasoning
- game-transcripts
- negotiation
- synthetic-data
configs:
- config_name: primary
  data_files:
  - split: train
    path: data/primary/*.jsonl.gz
- config_name: conditional
  data_files:
  - split: train
    path: data/conditional/*.jsonl.gz
- config_name: neutral_calibration
  data_files:
  - split: train
    path: data/neutral_calibration/*.jsonl.gz
- config_name: canonical
  data_files:
  - split: train
    path: data/canonical/*.jsonl.gz
- config_name: theysing
  data_files:
  - split: train
    path: data/theysing/train.jsonl
  - split: validation
    path: data/theysing/validation.jsonl
  - split: test
    path: data/theysing/test.jsonl
---

# Strategy-disposition gameplay corpus v2

Private research release. This v2 package preserves the July v1 release files and appends two completed high-reasoning Court episodes, plus 443 July-schema TheySing action and diplomacy-message rows. The original v1 Court, TheySing, and Alpha Centauri-style data remain in the baseline; no new Centauri games were generated.

## v2 additions

- **Court:** two completed games (5 and 6 seats), with canonical episode rows plus 224 primary and 224 conditional `aicourt.strategy-sft.v1` examples. All 224 model calls succeeded; all 112 action-phase examples were engine-legal (100%). Model metadata is `gpt-6.1-sol`, high reasoning. A third Court run stopped before completion when the Codex usage limit was reached and is excluded.
- **TheySing:** 443 rows using the historical `{schema,id,split,kind,payload}` format. The rows preserve synthetic public/private game messages and accepted actions. They include one one-turn pilot and actions/messages from seven completed turns of a separate unfinished run. No terminal outcome is claimed.

The v2 additions use separate dataset configs where their historical row schemas differ. The TheySing config uses the July `theysing.trainingRecord.v1` payload shape. The main strategy configs retain the July `aicourt.strategy-sft.v1` training schema and unified episode format.

Canonical episodes retain in-game private communications and hidden role metadata because those fields are part of the environment record. This release excludes model-call archives, raw provider responses, native run directories, prompts, workspaces, automation logs, staging data, session stores, credentials, and quarantined failures. Model-authored content is synthetic; adjudicated outcomes and source checks are the stronger evidence fields.

See `release_manifest.json` for v2 totals, `release_manifest_v1.json` for the exact July baseline, and `v2_additions_manifest.json` for appended files, hashes, and run receipts. No standalone data license is asserted in this private snapshot; downstream use remains subject to applicable model-provider terms.

